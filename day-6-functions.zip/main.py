import hurdle


def fn():
    print("Hello World")


fn()
